#include <iostream>
using namespace std;

int main() {
    // Declarar los números y la variable suma
    double num1 = 53;
    double num2 = -27;
    double num3 = 0.005;
    double suma;

    // Realizar la suma
    suma = num1 + num2 + num3;

    // Mostrar el resultado
    cout << "La suma de los tres números es: " << suma << endl;

    return 0;
}